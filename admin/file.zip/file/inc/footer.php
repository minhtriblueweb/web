</div>
<footer class="main-footer text-center text-sm">
  <p class="mb-1">Minh Trí Web</p>
  <p class="mb-1">
    Địa chỉ: Lầu 2, Số 27 Trường Chinh, Phường Tân Thới Nhất, Quận 12, Thành phố Hồ Chí Minh, Việt Nam
  </p>
  <p class="mb-1">Tel: 0328 732 834</p>
  <p class="mb-0">Email: minhtri.blueweb@gmail.com</p>
</footer>
</div>
<!-- Js all -->
<!-- Js Config -->
<script type="text/javascript">
var PHP_VERSION = 80309;
var CONFIG_BASE = "<?php echo $config['base'] ?>";
var TOKEN = "4cfd9a6ec93f31ec5006af2f97389efa";
var ADMIN = "admin";
var ASSET = "<?php echo $config['base'] ?>";
var LINK_FILTER = "";
var ID = 0;
var COM = "";
var ACT = "";
var TYPE = "";
var HASH = "EBV0iw3wzr";
var ACTIVE_GALLERY = false;
var BASE64_QUERY_STRING = "";
var LOGIN_PAGE = false;
var MAX_DATE = "2024/09/08";
var CHARTS = {
  month: "09",
  series: [
    15000, 16000, 18000, 28089, 16000, 19000, 22000, 15000, 8500, 12000, 15968, 5896, 14369, 13985, 17859, 18596,
    24158, 24658, 20148, 12058, 17896, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0,
  ],
  labels: [
    "D1",
    "D2",
    "D3",
    "D4",
    "D5",
    "D6",
    "D7",
    "D8",
    "D9",
    "D10",
    "D11",
    "D12",
    "D13",
    "D14",
    "D15",
    "D16",
    "D17",
    "D18",
    "D19",
    "D20",
    "D21",
    "D22",
    "D23",
    "D24",
    "D25",
    "D26",
    "D27",
    "D28",
    "D29",
    "D30",
  ],
};
var ADD_OR_EDIT_PERMISSIONS = false;
var IMPORT_IMAGE_EXCELL = false;
var ORDER_ADVANCED_SEARCH = false;
var ORDER_MIN_TOTAL = 1;
var ORDER_MAX_TOTAL = 1;
var ORDER_PRICE_FROM = 1;
var ORDER_PRICE_TO = 1;
var LANG = {
  taithembinhluan: "Tải thêm bình luận",
  xemthembinhluan: "Xem thêm bình luận",
  traloi: "Trả lời",
  dangtai: "Đang tải",
  huybo: "Hủy bỏ",
  duyet: "Duyệt",
  boduyet: "Bỏ duyệt",
  timkiem: "Tìm kiếm",
  thongbao: "Thông báo",
  chondanhmuc: "Chọn danh mục",
  dulieukhonghople: "Dữ liệu không hợp lệ",
  dinhdanghinhanhkhonghople: "Định dạng hình ảnh không hợp lệ",
  dungluonghinhanhlondungluongchopheplt4mb4096kb: "Dung lượng hình ảnh lớn. Dung lượng cho phép &lt;= 4MB ~ 4096KB",
  xoabinhluanthanhcong: "Xóa bình luận thành công",
  banmuonxoabinhluannay: "Bạn muốn xóa bình luận này ?",
  capnhattrangthaithanhcong: "Cập nhật trạng thái thành công",
  phanhoithanhcong: "Phản hồi thành công",
  hethongbiloivuilongthulaisau: "Hệ thống bị lỗi. Vui lòng thử lại sau.",
  duongdankhonghople: "Đường dẫn không hợp lệ",
  banhaychonitnhat1mucdegui: "Bạn hãy chọn ít nhất 1 mục để gửi",
  albumhientai: "Album hiện tại",
  chontatca: "Chọn tất cả",
  sapxep: "Sắp xếp",
  dongy: "Đồng ý",
  xoatatca: "Xóa tất cả",
  cothechonnhieuhinhdedichuyen: "Có thể chọn nhiều hình để di chuyển",
  xulythatbaivuilongthulaisau: "Xử lý thất bại. Vui lòng thử lại sau.",
  banmuondaytinnay: "Bạn muốn đẩy tin này ?",
  banmuonguithongtinchocacmucdachon: "Bạn muốn gửi thông tin cho các mục đã chọn ?",
  bancochacmuonxoamucnay: "Bạn có chắc muốn xóa mục này ?",
  bancochacmuonxoanhungmucnay: "Bạn có chắc muốn xóa những mục này ?",
  dulieuhinhanhkhonghople: "Dữ liệu hình ảnh không hợp lệ",
  noidungseodaduocthietlapbanmuontaolainoidungseo: "Nội dung SEO đã được thiết lập. Bạn muốn tạo lại nội dung SEO ?",
  bancochacmuonxoahinhanhnay: "Bạn có chắc muốn xóa hình ảnh này ?",
  bancochacmuonxoacachinhanhdachon: "Bạn có chắc muốn xóa các hình ảnh đã chọn ?",
  keovathahinhvaoday: "Kéo và thả hình vào đây",
  hoac: "hoặc",
  hinhanh: "Hình ảnh",
  chonhinh: "Chọn hình",
  chiduocuploadmoilan: "Chỉ được upload mỗi lần",
  themhinh: "Thêm hình",
  vuilongchonhinhanh: "Vui lòng chọn hình ảnh",
  nhunghinhdaduocchon: "Những hình đã được chọn",
  keohinhvaodaydeupload: "Kéo hình vào đây để upload",
  banmuonloaibohinhanhnay: "Bạn muốn loại bỏ hình ảnh này ?",
  uploadhinhanh: "Upload hình ảnh",
  sothutu: "Số thứ tự",
  chihotrotaptinlahinhanhcodinhdang: "Chỉ hỗ trợ tập tin là hình ảnh có định dạng",
  cokichthuocqualonvuilonguploadhinhanhcokichthuoctoida: "có kích thước quá lớn. Vui lòng upload hình ảnh có kích thước tối đa",
  nhunghinhanhbanchoncokichthuocqualonvuilongchonnhunghinhanhcokichthuoctoida: "Những hình ảnh bạn chọn có kích thước quá lớn. Vui lòng chọn những hình ảnh có kích thước tối đa",
};
</script>

<!-- Js Files -->
<script src="./assets/js/jquery.min.js"></script>
<script src="./assets/js/moment.min.js"></script>
<script src="./assets/confirm/confirm.js"></script>
<script src="./assets/select2/select2.full.js"></script>
<script src="./assets/sumoselect/jquery.sumoselect.js"></script>
<script src="./assets/datetimepicker/php-date-formatter.min.js"></script>
<script src="./assets/datetimepicker/jquery.mousewheel.js"></script>
<script src="./assets/datetimepicker/jquery.datetimepicker.js"></script>
<script src="./assets/daterangepicker/daterangepicker.js"></script>
<script src="./assets/rangeSlider/ion.rangeSlider.js"></script>
<script src="./assets/js/jquery.priceformat.min.js"></script>
<script src="./assets/jscolor/jscolor.js"></script>
<script src="./assets/filer/jquery.filer.js"></script>
<script src="./assets/holdon/HoldOn.js"></script>
<script src="./assets/sortable/Sortable.js"></script>
<script src="./assets/js/bootstrap.js"></script>
<script src="./assets/js/adminlte.js"></script>
<script src="./assets/apexcharts/apexcharts.min.js"></script>
<script src="./assets/simplenotify/simple-notify.js"></script>
<script src="./assets/comment/comment.js"></script>
<script src="./assets/fancybox5/fancybox.umd.js"></script>
<script src="./assets/js/apps.js"></script>
<script src="ckeditor/ckeditor.js"></script>
</body>

</html>